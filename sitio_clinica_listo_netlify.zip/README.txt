
Clínica Rural Integral – Sitio estático listo para publicar

Contenido:
- index.html  → Página principal (auto-contenida: estilos, imágenes en base64 y videos embebidos).
- 404.html    → Página de error personalizada.
- robots.txt  → SEO básico.
- sitemap.xml → Mapa del sitio (con anclas principales).
- favicon.ico / favicon.png → Ícono del sitio.
- README.txt  → Este archivo con instrucciones.

Cómo publicarlo con Netlify Drop:
1) Comprime esta carpeta en un ZIP (los archivos deben quedar en la raíz del ZIP).
2) Ve a https://app.netlify.com/drop y arrastra el ZIP.
3) Netlify te dará una URL pública (por ejemplo, https://tu-sitio.netlify.app).

Sugerencias:
- Si subes archivos adicionales o cambias rutas, asegúrate de mantener index.html en la raíz.
- Para GitHub Pages: sube todo a un repo y activa Pages en Settings → Pages (Branch main, carpeta root).
- Para Vercel: https://vercel.com/new → crea un proyecto estático y arrastra esta carpeta.
